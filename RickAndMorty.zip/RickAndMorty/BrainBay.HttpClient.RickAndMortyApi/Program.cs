﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using BrainBay.HttpClient.RickAndMortyApi.BrainBay.RickAndMorty.Service;

namespace BrainBay.HttpClient.RickAndMortyApi
{
    public class Program
    {
        static async Task<int> Main(string[] args)
        {


            // Get Characters Information from the api https://rickandmortyapi.com/api/character/

            var characters = await ReadRickAndMortyApi.GetCharacters();


            bool showMenu = true;
            while (showMenu)
            {
                showMenu = MainMenu(characters);
            }
            
            return 0;
        }

        private static bool MainMenu(List<CharacterModel>characters)
        {
            var datfeed = new DataFeed();

            //Console.Clear();
            Console.WriteLine("Choose Status:");
            Console.WriteLine("1) Alive");
            Console.WriteLine("2) Dead");
            Console.WriteLine("3) Unknown");
            Console.WriteLine("4) Exit");
           
            Console.Write("\r\n Select Status: ");

            switch(Console.ReadLine())
            {
                case "1":
                    if(datfeed.DisplayResult(characters, "Alive"))
                    {
                        datfeed.AddCharacter(characters, "Alive");
                    }
                    return true;
                case "2":
                    if (datfeed.DisplayResult(characters, "Dead"))
                    {
                        datfeed.AddCharacter(characters, "Dead");
                    }
                    return true;
                case "3":
                    //datfeed.AddCharacter(characters, "Unknown");
                    if (datfeed.DisplayResult(characters, "unknown"))
                    {
                        datfeed.AddCharacter(characters, "unknown");
                    }
                    return true;
                case "4" :
                    return false;
                default:
                    return true;
            }
        }
    }
}

