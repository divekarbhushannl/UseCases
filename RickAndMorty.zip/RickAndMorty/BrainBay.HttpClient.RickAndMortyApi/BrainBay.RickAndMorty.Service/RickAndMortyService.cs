﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace BrainBay.HttpClient.RickAndMortyApi.BrainBay.RickAndMorty.Service
{
    public class RickAndMortyService: IRickAndMortyService
    {

        private readonly IHttpClientFactory _clientFactory;

        public RickAndMortyService(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        
        public async Task<ResponseModel> GetCharacterByStatusAsync()
        {
            var request = new HttpRequestMessage(HttpMethod.Get,
                "https://rickandmortyapi.com/api/character/");
            var client = _clientFactory.CreateClient();
            var response = await client.SendAsync(request);

            if (!response.IsSuccessStatusCode)
                return null;
            


            var str = await response.Content.ReadAsStringAsync();

            ResponseModel res = JsonConvert.DeserializeObject<ResponseModel>(str);
            

            return res;
            
        }

    }
}
