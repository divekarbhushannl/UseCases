﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace BrainBay.HttpClient.RickAndMortyApi.BrainBay.RickAndMorty.Service
{
    public static class StreamExtensions
    {
        public static T Deserialize<T>(this Stream stream) where T : class
        {
            if (stream == null)
                return default(T);

            using (var streamReader = new StreamReader(stream))
            using (var jsonReader = new JsonTextReader(streamReader))
            {
                return new JsonSerializer().Deserialize<T>(jsonReader);
            }
        }

        public static T DeserializeObject<T>(this string input) where T : class
        {
            if (input == string.Empty)
                return default(T);

            using (var stringReader = new StringReader(input))
            using (var jsonReader = new JsonTextReader(stringReader))
            {
                return new JsonSerializer().Deserialize<T>(jsonReader);
            }
        }

        public static IEnumerable<T> DeserializeObjects<T>(this string input) where T : class
        {
            JsonSerializer serializer = new JsonSerializer();
            using (var strreader = new StringReader(input))
            using (var jsonreader = new JsonTextReader(strreader))
            {
                //you should use this line
                jsonreader.SupportMultipleContent = true;
                while (jsonreader.Read())
                {
                    yield return serializer.Deserialize<T>(jsonreader);
                }

            }
        }
    }
}
