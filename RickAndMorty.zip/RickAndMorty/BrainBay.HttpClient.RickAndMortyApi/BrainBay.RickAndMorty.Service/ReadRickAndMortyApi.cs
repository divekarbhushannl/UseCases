﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace BrainBay.HttpClient.RickAndMortyApi.BrainBay.RickAndMorty.Service
{
    public static class ReadRickAndMortyApi
    {
        //public static ReadRickAndMortyApi()
        //{

        //}

        public static async Task<ResponseModel> GetResponse()
        {
            var builder = new HostBuilder()
            .ConfigureServices((hostContext, services) =>
            {
                services.AddHttpClient();
                
                services.AddTransient<IRickAndMortyService, RickAndMortyService>();

            }).UseConsoleLifetime();

            var host = builder.Build();

            using (var serviceScope = host.Services.CreateScope())
            {
                var services = serviceScope.ServiceProvider;

                try
                {
                    var rickandmortyService = services.GetRequiredService<IRickAndMortyService>();
                    var response = await rickandmortyService.GetCharacterByStatusAsync();
                    
                    //foreach (var character in response.results)
                    //{
                    //    Console.WriteLine("id: {0},Name: {1},Status:{2},", character.Id, character.Name, character.Status);
                    //}
                    return response;
                   
                }
                catch (Exception ex)
                {
                    var logger = services.GetRequiredService<ILogger<Program>>();

                    logger.LogError(ex, "An error occurred.");
                    return null;
                } 
                
            }

        }

        public static async Task <List<CharacterModel>> GetCharacters()
        {
            var response = await GetResponse();
            return response.results;

        }
    }
}
