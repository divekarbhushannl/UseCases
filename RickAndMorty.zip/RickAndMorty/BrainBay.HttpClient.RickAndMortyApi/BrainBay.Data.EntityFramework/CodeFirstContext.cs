﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
//using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer;


namespace BrainBay.HttpClient.RickAndMortyApi.BrainBay.Data.EntityFramework
{
    public class CodeFirstContext : DbContext
    {
        public DbSet<Character> Characters { get; set; }
        public DbSet<OriginData> Origins { get; set; }
        public DbSet<LocationData> Locations { get; set; }
        public DbSet<Episode> Episodes { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["CodeFirstContext"].ConnectionString;
            // optionsBuilder.UseSqlServer(@"Server = localhost;Database = CharacterDB;Trusted_Connection = True;");
            optionsBuilder.UseSqlServer(connectionString);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Episode>()
              .HasKey(t => t.EpisodeId);


            modelBuilder.Entity<Character>()
                .HasOne(b => b.Origin)
                .WithOne(i => i.Character)
                .HasForeignKey<OriginData>(b => b.Id);

            modelBuilder.Entity<Character>()
                .HasOne(b => b.Location)
                .WithOne(i => i.Character)
                .HasForeignKey<LocationData>(b => b.Id);

            modelBuilder.Entity<Episode>()
                .HasOne(b => b.Character)
                .WithMany(i => i.Episodes)
                .HasForeignKey(b => b.Id);
        }
    }
    
    public class Character
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public string Species { get; set; }
        public string Type { get; set; }
        public string Gender { get; set; }
       
        public OriginData Origin { get; set; }
        public LocationData Location { get; set; }
        public string Image { get; set; }
        

        public List<Episode> Episodes { get; set; }
        public string Url { get; set; }
        public DateTime Created { get; set; }
    }
    public class OriginData
    {
        
        public string Name { get; set; }
        public string Url { get; set; }

        public int Id { get; set; }
        public Character Character { get; set; }
        
    }
    public class LocationData
    {
        
        public string Name { get; set; }
        public string Url { get; set; }
        public int Id { get; set; }
        public Character Character { get; set; }
        
    }
    public class Episode
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EpisodeId { get; set; }
        public string EpisodeName { get; set; }
        public int Id { get; set; }
        public Character Character { get; set; }
        
    }
}
