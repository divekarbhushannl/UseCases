﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BrainBay.HttpClient.RickAndMortyApi.BrainBay.Data.EntityFramework
{
    public class DataAccessHelper
    {
        readonly CodeFirstContext _dbContext = new CodeFirstContext();

        public void EnsureDatabaseCreated()
        {
            _dbContext.Database.EnsureCreated();
        }
        public void AddCharacter(Character characters)
        {
            _dbContext.Characters.Add(characters);
            _dbContext.SaveChanges();
           
        }

        //public void AddOrigin(OriginData origin)
        //{
        //    _dbContext.Origins.Add(origin);
        //    _dbContext.SaveChanges();
        //    //return origin.Id;
        //}

        //public void AddLocation(LocationData location)
        //{
        //    _dbContext.Locations.Add(location);
        //    _dbContext.SaveChanges();
        //   // return location.Id;
        //}

        //public void AddEpisode(List<Episode> episode)
        //{
        //    foreach(var episd in episode)
        //    {
        //        _dbContext.Episodes.Add(episd);
        //    }
            
        //    _dbContext.SaveChanges();
        //   // return episode.Id;
        //}
    }   
}
