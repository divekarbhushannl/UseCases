﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using BrainBay.HttpClient.RickAndMortyApi.BrainBay.RickAndMorty.Service;
using BrainBay.HttpClient.RickAndMortyApi.BrainBay.Data.EntityFramework;

namespace BrainBay.HttpClient.RickAndMortyApi
{
    public class DataFeed
    {
        public Character character = null;
        public List<Episode> episodeList = null;
        public OriginData origindata = null;
        public LocationData locationdata = null;

        public void AddCharacter(List<CharacterModel>Characters,string status)
        {
            DataAccessHelper dbHelper = new DataAccessHelper();
            dbHelper.EnsureDatabaseCreated();

            var characterobjectwithAliveStatus = Characters.Where(c => c.Status == status).ToList();
            try
            {
                foreach (var characterobj in characterobjectwithAliveStatus)
                {
                    episodeList = new List<Episode>();
                    character = new Character();
                    origindata = new OriginData();
                    locationdata = new LocationData();

                    character.Id = characterobj.Id;
                    character.Name = characterobj.Name;
                    character.Status = characterobj.Status;
                    character.Species = characterobj.Species;
                    character.Type = characterobj.Type;
                    character.Gender = characterobj.Gender;
                    character.Image = characterobj.Image;

                    origindata.Id = characterobj.Id;
                    origindata.Name = characterobj.Origin.Name;
                    origindata.Url = characterobj.Origin.Url;
                    character.Origin = origindata;


                    locationdata.Id = characterobj.Id;
                    locationdata.Name = characterobj.Location.Name;
                    locationdata.Url = characterobj.Location.Url;
                    character.Location = locationdata;

                    character.Url = characterobj.Url;
                    character.Created = characterobj.Created;
                    foreach (var strEpisode in characterobj.Episode)
                    {
                        var episode = new Episode();
                        episode.EpisodeName = strEpisode;
                        episode.Id = characterobj.Id;
                        episodeList.Add(episode);
                    }
                    character.Episodes = episodeList;
                    origindata.Character = character;
                    locationdata.Character = character;

                    dbHelper.AddCharacter(character);
                    
                }
                Console.WriteLine("\n\nEntries added Successfully.\n");
            }
            catch(Exception ex)
            {
                Console.WriteLine("\nThe respected information is already present in the Database.\n");
            }
           


        }

        public bool  DisplayResult(List<CharacterModel> Characters,string status)
        {
            var characterobjectwithStatus = GetCharactersbyStatus(Characters, status);

            foreach (var character in characterobjectwithStatus)
            {
                Console.WriteLine("id: {0},Name: {1},Status:{2},", character.Id, character.Name, character.Status);
            }

            Console.WriteLine("\r\nYou want add into Database: Y/N");
            switch(Console.ReadLine())
            {   
                case "Y":
                    return true;
                case "N":
                    return false;
                default:
                    return false;
            }
        }

        public List<CharacterModel>GetCharactersbyStatus(List<CharacterModel> Characters, string status)
        {
            return Characters.Where(c => c.Status == status).ToList();
        }
    }
}
