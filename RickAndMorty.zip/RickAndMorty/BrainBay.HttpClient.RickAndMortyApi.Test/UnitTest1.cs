using NUnit.Framework;
using System.Threading.Tasks;
using BrainBay.HttpClient.RickAndMortyApi.BrainBay.RickAndMorty.Service;
using System.Collections.Generic;

namespace BrainBay.HttpClient.RickAndMortyApi.Test
{
    public class Tests
    {
        public static List<CharacterModel> characters = new List<CharacterModel>();
        //[SetUp]
        //public void Setup()
        [SetUp]
        public static async Task Setup()
        {
            var response = await ReadRickAndMortyApi.GetResponse();
            characters = response.results;
        }
      
        [Test]
        public void Test_With_Retrival_of_Charaters_From_RestAPI()
        {
            Assert.AreEqual(characters.Count, 20);
        }
        [Test]
        public void Test_With_RestAPI_For_Characters_With_Alive_Status()
        {
            DataFeed dataFeed = new DataFeed();
            var characterwithAliveStatus = dataFeed.GetCharactersbyStatus(characters,"Alive");
            Assert.AreEqual(characterwithAliveStatus.Count, 8);
        }
        [Test]
        public void Test_With_RestAPI_For_Characters_With_Dead_Status()
        {
            DataFeed dataFeed = new DataFeed();
            var characterwithAliveStatus = dataFeed.GetCharactersbyStatus(characters, "Dead");
            Assert.AreEqual(characterwithAliveStatus.Count, 6);
        }
        [Test]
        public void Test_With_RestAPI_For_Characters_With_unknown_Status()
        {
            DataFeed dataFeed = new DataFeed();
            var characterwithAliveStatus = dataFeed.GetCharactersbyStatus(characters, "unknown");
            Assert.AreEqual(characterwithAliveStatus.Count, 6);
        }
    }
}